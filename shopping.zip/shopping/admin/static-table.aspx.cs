﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;

public partial class admin_static_table : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter sda;
    bool b = true;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
        BindRepeator();
    }
    // private void BindRepeator()
    //{


    //    com = new SqlCommand("select * from Signup_1 ", con);
    //    con.Open();
    //     sda = new SqlDataAdapter(com);
    //    DataTable dt = new DataTable();
    //    sda.Fill(dt);
    //    Repeater1.DataSource = dt;
    //    Repeater1.DataBind();
    //    con.Close();
    //}
     private void BindRepeator()
     {


         SqlCommand cmd = new SqlCommand("select * from Signup_1 order by sno", con);
         con.Open();
         Repeater1.DataSource = cmd.ExecuteReader();
         Repeater1.DataBind();
         con.Close();

     }
     protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
     {

     }
}


