﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;


public partial class admin_product_list : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter sda;
    bool b = true;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
        BindRepeator();
    }
    //private void BindRepeator()
    //{
    //    com = new SqlCommand("select * from food_stock ", con);
    //    con.Open();
    //    //Repeater1.DataSource = cmd.ExecuteReader();
    //    //Repeater1.DataBind();
    //    //con.Close();
    //    sda = new SqlDataAdapter(com);
    //    DataTable dt = new DataTable();
    //    //sda.Fill(dt);
    //    //GridView1.DataSource = dt;
    //    GridView1.DataBind();
    //    con.Close();
    //}
    private void BindRepeator()
    {


        SqlCommand com = new SqlCommand("select * from food_stock order by sno" , con);
        con.Open();
        Repeater1.DataSource = com.ExecuteReader();
        Repeater1.DataBind();
        con.Close();

    }
}