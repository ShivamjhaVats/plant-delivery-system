﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;




public partial class admin_product_edit : System.Web.UI.Page
{
   
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    bool b = true;
    string d1, t1;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
        //if (!IsPostBack)
        //{

        //    string com = "Select * from category_li";
        //    SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        //    DataTable dt = new DataTable();
        //    adpt.Fill(dt);

        //    DropDownList1.DataSource = dt;
        //    DropDownList1.DataBind();
        //    DropDownList1.DataTextField = "category";
        //    DropDownList1.DataValueField = "id";
        //    DropDownList1.DataBind();
        //}

    }

    private void add(DataTable d)
    {
        throw new NotImplementedException();
    }
    private void clear()
    {
       
        pname.Text = "";
        rprice.Text = "";
        sprice.Text = "";
        pquantity.Text = "";
        

    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {

        string pid;
        string cid;
        int inc = 0;
        con.Open();
        com = new SqlCommand(" select max(sno) from food_stock");
        com.Connection = con;
        dr = com.ExecuteReader();
        while (dr.Read())
        {
            inc = int.Parse(dr[0].ToString());
        }
        con.Close();
        d1 = DropDownList1.SelectedItem.Text;
        t1 = pname.Text;
        pid =  d1 + t1 + "000" + inc.ToString();
        cid = d1 + t1;

        //photo upload



        string photo = "";
        string photo2 = "";
        int cn = 0;
        cn = 1;
        if (FileUpload1.HasFile)
        {

            photo = cn.ToString() + FileUpload1.PostedFile.FileName;
            photo2 = Server.MapPath("image/") + photo;
            FileUpload1.SaveAs(photo2);
        }
        con.Open();
        com = new SqlCommand("insert into food_stock(p_id,c_id,p_name,regular_price,quantity,sale_price,image) values('" + pid.ToString() + "','" + cid.ToString() + "','" + pname.Text + "','" + rprice.Text + "','" + pquantity.Text + "','" + sprice.Text + "','" + photo.ToString() + "') ");
        com.Connection = con;
        com.ExecuteNonQuery();
        clear();  //clear function is called it
        Response.Write("<script>alert('Product is Upload')</script>");
        con.Close();

    }


    public System.Data.DataTable dt { get; set; }
}
