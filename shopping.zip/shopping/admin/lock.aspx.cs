﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;

public partial class admin_lock : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    bool b = true;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
    }
    //With the Help of Decryption ,password will store in database this formet (AD><U$*@$) but matching time automatic convert this formet (123).
    public string Decrypt(string str)
    {
        if (str == null) throw new ArgumentNullException("str");
        byte[] data = Convert.FromBase64String(str);
        byte[] decrypted = ProtectedData.Unprotect(data, null, DataProtectionScope.CurrentUser);
        return Encoding.Unicode.GetString(decrypted);
    }

    //Decryption end.
    protected void Button1_Click(object sender, EventArgs e)
    {
 con.Open();
        com = new SqlCommand(" select * from admin_reg ");
        com.Connection = con;
        dr = com.ExecuteReader();


        while (dr.Read())
        {
            
            string pass = dr[1].ToString();
            string pass1 = Decrypt(pass);      //decryption function is calling it place
            if (pass1.ToString() == TextBox1.Text)
            {
                b = false;
                Session["k1"] = dr[2].ToString();
                Response.Redirect("index.aspx");
                break;
            }
        }
        if (b == true)
        {
            Response.Write("<script>alert('invalid password')</script>");
        }
        else
        {
            b = true;
        }
    }
    }
