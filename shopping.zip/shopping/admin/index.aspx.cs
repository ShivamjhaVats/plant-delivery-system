﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;

public partial class admin_index : System.Web.UI.Page
{
   
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    int inc;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
        con.Open();
        com = new SqlCommand(" select max(sno) from Signup_1");
        com.Connection = con;
        dr = com.ExecuteReader();
        while (dr.Read())
        {
            inc = int.Parse(dr[0].ToString());

        }
        con.Close();
        Label2.Text = inc.ToString();
    }
}