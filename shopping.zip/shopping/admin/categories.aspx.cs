﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;

public partial class admin_categories : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    bool b = true;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
        BindRepeator();
    }

    private void clear()
    {
        id1.Text = "";
        categories.Text = "";

    }
    protected void add1_Click(object sender, EventArgs e)
    //{

    //     //encryption function is calling it place
    //    con.Open();
    //    com = new SqlCommand("insert into category_li values('" + id1.Text + "','" + categories.Text + "') ");
    //    com.Connection = con;
    //    com.ExecuteNonQuery();
    //    clear();  //clear function is called it
    //    Response.Write("<script>alert('Category is Update')</script>");
    //    con.Close();

    //}
    {
        string photo = "";
        string photo2 = "";
        int cn = 0;
        cn = 1;
        if (FileUpload1.HasFile)
        {

            photo = cn.ToString() + FileUpload1.PostedFile.FileName;
            photo2 = Server.MapPath("image_c/") + photo;
            FileUpload1.SaveAs(photo2);
        }
        con.Open();
        com = new SqlCommand("insert into category_li(id,category,image) values('" + id1.Text + "','" + categories.Text + "','" + photo.ToString() + "') ");
        com.Connection = con;
        com.ExecuteNonQuery();
        clear();  //clear function is called it
        Response.Write("<script>alert('Category is Update')</script>");
        con.Close();
        Response.Redirect("categories.aspx");

    }
    private void BindRepeator()
    {


        SqlCommand cmd = new SqlCommand("select * from category_li order by sno", con);
        con.Open();
        Repeater1.DataSource = cmd.ExecuteReader();
        Repeater1.DataBind();
        con.Close();

    }
}