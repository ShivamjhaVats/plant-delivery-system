﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;
public partial class admin_register : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    bool b = true;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
    }
    //With the help of Encryption, passwoed will send in database this formet (123) but store in this formet (AD><U$*@$). 
    public string Encrypt(string str)
    {
        if (str == null) throw new ArgumentNullException("str");
        var data = Encoding.Unicode.GetBytes(str);
        byte[] encrypted = ProtectedData.Protect(data, null, DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(encrypted);
    }
    //Encryption end.

    //With the Help of Decryption ,password will store in database this formet (AD><U$*@$) but matching time automatic convert this formet (123).
    public string Decrypt(string str)
    {
        if (str == null) throw new ArgumentNullException("str");
        byte[] data = Convert.FromBase64String(str);
        byte[] decrypted = ProtectedData.Unprotect(data, null, DataProtectionScope.CurrentUser);
        return Encoding.Unicode.GetString(decrypted);
    }

    //Decryption end.
    //After the click submit button the textbox data will be cleared,with the healp of clear() function.
    private void clear()
    {
        name1.Text = "";
        email1.Text = "";
        password1.Text = "";
        password2.Text = "";
        email2.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string pass = password1.Text;
        string pass1 = Encrypt(pass);  //encryption function is calling it place
        con.Open();
        com = new SqlCommand("insert into admin_reg values('" + name1.Text + "','" + pass1.ToString() + "','" + email1.Text + "') ");
        com.Connection = con;
        com.ExecuteNonQuery();
        clear();  //clear function is called it
        con.Close();
    }
}