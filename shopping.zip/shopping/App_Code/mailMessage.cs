﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class mailMessage
{
    public System.Net.Mail.MailAddress From { get; set; }

    public string Subject { get; set; }

    public string Body { get; set; }
}
