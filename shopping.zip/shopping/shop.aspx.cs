﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Configuration;

public partial class shop : System.Web.UI.Page
{
    StringBuilder sb = new StringBuilder();
    SqlConnection con;
    SqlCommand com;
    SqlDataAdapter da;
    DataTable dt = new DataTable();
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");

        RepeterData();
    }
    public void RepeterData()
    {
        con.Open();
        com = new SqlCommand("Select * from food_stock Order By sno desc", con);
        DataSet ds = new DataSet();
        da = new SqlDataAdapter(com);
        da.Fill(ds);
        Repeater1.DataSource = ds;
        Repeater1.DataBind();
    } 
}