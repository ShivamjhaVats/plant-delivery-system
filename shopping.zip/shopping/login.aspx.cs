﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;


public partial class login : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    SqlDataReader dr;
    bool b = true;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
    }
    //With the help of Encryption, passwoed will send in database this formet (123) but store in this formet (AD><U$*@$). 
    public string Encrypt(string str)
    {
        if (str == null) throw new ArgumentNullException("str");
        var data = Encoding.Unicode.GetBytes(str);
        byte[] encrypted = ProtectedData.Protect(data, null, DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(encrypted);
    }
    //Encryption end.

    //With the Help of Decryption ,password will store in database this formet (AD><U$*@$) but matching time automatic convert this formet (123).
    public string Decrypt(string str)
    {
        if (str == null) throw new ArgumentNullException("str");
        byte[] data = Convert.FromBase64String(str);
        byte[] decrypted = ProtectedData.Unprotect(data, null, DataProtectionScope.CurrentUser);
        return Encoding.Unicode.GetString(decrypted);
    }

    //Decryption end.
    //After the click submit button the textbox data will be cleared,with the healp of clear() function.
    private void clear()
    {
        name1.Text = "";
        email1.Text = "";
        mobile1.Text = "";
        address1.Text = "";
        password1.Text = "";
        cpassword1.Text = "";

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string pass = password1.Text;
        string pass1 = Encrypt(pass);  //encryption function is calling it place
        con.Open();
        com = new SqlCommand("insert into Signup_1 values('" + name1.Text + "','" + email1.Text + "','" + mobile1.Text + "','" + address1.Text + "','" + pass1.ToString() + "') ");
        com.Connection = con;
        com.ExecuteNonQuery();
        clear();  //clear function is called it
        con.Close();

    }


    protected void Button1_Click(object sender, EventArgs e)
    {

        con.Open();
        com = new SqlCommand(" select * from Signup_1 ");
        com.Connection = con;
        dr = com.ExecuteReader();


        while (dr.Read())
        {
            string unam = dr[2].ToString();
            string pass = dr[5].ToString();
            string pass1 = Decrypt(pass);      //decryption function is calling it place
            if (unam.ToString() == TextBox2.Text && pass1.ToString() == TextBox1.Text)
            {
                b = false;
                Session["k1"] = dr[2].ToString();
                Response.Redirect("index.aspx");
                break;
            }
        }
        if (b == true)
        {
            Response.Write("<script>alert('invalid userid and password')</script>");
        }
        else
        {
            b = true;
        }
    }
    public partial class forget : System.Web.UI.Page
    {
        protected void Page_load(object sender, EventArgs e)
        {
        }
       

    }
    protected void forgot1_Click(object sender, EventArgs e)
    {
        string pass = "";
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=shoppin;Integrated Security=True");
        SqlCommand cmd = new SqlCommand("select pass from Signup_1 where email=@email", con);
        cmd.Parameters.AddWithValue("email", forgot_pass.Text);
        con.Open();
        using (SqlDataReader sdr = cmd.ExecuteReader())
        {
            if (sdr.Read())
            {
                pass = sdr["pass"].ToString();
            }
        }
        con.Close();
        if (!string.IsNullOrEmpty(pass))
        {
            string p1 = "";
            p1 = Decrypt(pass).ToString();
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress("govindpatnaism@gmail.com");
            msg.To.Add(forgot_pass.Text);
            msg.Subject = "Recover Your password";
            msg.Body = ("Your Password is:" + p1);
            msg.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            System.Net.NetworkCredential ntwd = new NetworkCredential();
            ntwd.UserName = "govindpatnaism@gmail.com";
            ntwd.Password = "7631351626";
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = ntwd;
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.Send(msg);

        }
    }
}
